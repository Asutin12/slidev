// lib/signalr.ts
import * as signalR from "@microsoft/signalr";

export interface ChatMessage {
  sender: string;
  text: string;
  timestamp: string;
}

export class SignalRService {
  private connection: signalR.HubConnection | null = null;
  private onMessageCallback: ((message: ChatMessage) => void) | null = null;
  private apiBaseUrl: string;

  constructor() {
    // ローカル開発とAzure環境での切り替え
    this.apiBaseUrl = process.env.NEXT_PUBLIC_API_BASE_URL || "/api";
  }

  async startConnection(): Promise<void> {
    try {
      // negotiateエンドポイントから接続情報を取得
      const response = await fetch(`${this.apiBaseUrl}/negotiate`, {
        method: "POST",
      });

      if (!response.ok) {
        throw new Error("Failed to get connection info");
      }

      const connectionInfo = await response.json();

      // SignalR接続の構築
      this.connection = new signalR.HubConnectionBuilder()
        .withUrl(connectionInfo.url, {
          accessTokenFactory: () => connectionInfo.accessToken,
        })
        .withAutomaticReconnect()
        .build();
      // メッセージ受信ハンドラーの設定
      this.connection.on("newMessage", (message: ChatMessage) => {
        if (this.onMessageCallback) {
          this.onMessageCallback(message);
        }
      });

      // 接続開始
      await this.connection.start();
      console.log("SignalR接続成功");
    } catch (error) {
      console.error("SignalR接続エラー:", error);
      throw error;
    }
  }

  async sendMessage(sender: string, text: string): Promise<void> {
    const response = await fetch(`${this.apiBaseUrl}/messages`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ sender, text }),
    });

    if (!response.ok) {
      throw new Error("Failed to send message");
    }
  }

  onMessage(callback: (message: ChatMessage) => void): void {
    this.onMessageCallback = callback;
  }

  async stopConnection(): Promise<void> {
    if (this.connection) {
      await this.connection.stop();
    }
  }
}
