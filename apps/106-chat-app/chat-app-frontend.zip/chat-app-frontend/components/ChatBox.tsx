// components/ChatBox.tsx
"use client";

import { ChatMessage } from "@/lib/signalr";

interface ChatBoxProps {
  messages: ChatMessage[];
}

export default function ChatBox({ messages }: ChatBoxProps) {
  return (
    <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50">
      {messages.map((message, index) => (
        <div
          key={index}
          className="bg-white rounded-lg shadow-sm p-4 hover:shadow-md transition-shadow"
        >
          <div className="flex items-start justify-between">
            <span className="font-semibold text-blue-600">
              {message.sender}
            </span>
            <span className="text-xs text-gray-400">
              {new Date(message.timestamp).toLocaleTimeString("ja-JP")}
            </span>
          </div>
          <p className="mt-2 text-gray-800">{message.text}</p>
        </div>
      ))}
    </div>
  );
}
