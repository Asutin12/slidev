// app/page.tsx
"use client";

import { useEffect, useState, useRef } from "react";
import { SignalRService, ChatMessage } from "@/lib/signalr";
import ChatBox from "@/components/ChatBox";
import MessageInput from "@/components/MessageInput";
import UserInfo from "@/components/UserInfo";

export default function Home() {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [currentUser, setCurrentUser] = useState("Anonymous");
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isConnected, setIsConnected] = useState(false);
  const signalRService = useRef<SignalRService | null>(null);

  useEffect(() => {
    // ユーザー情報の取得
    getUserInfo();

    // SignalR接続の初期化
    const initSignalR = async () => {
      const service = new SignalRService();
      signalRService.current = service;

      service.onMessage((message) => {
        setMessages((prev) => [...prev, message]);
      });

      try {
        await service.startConnection();
        setIsConnected(true);
      } catch (error) {
        console.error("接続エラー:", error);
      }
    };

    initSignalR();

    return () => {
      if (signalRService.current) {
        signalRService.current.stopConnection();
      }
    };
  }, []);

  const getUserInfo = async () => {
    try {
      const response = await fetch("/.auth/me");
      const payload = await response.json();
      const { clientPrincipal } = payload;

      if (clientPrincipal) {
        setCurrentUser(clientPrincipal.userDetails);
        setIsAuthenticated(true);
      }
    } catch (error) {
      console.log("未認証ユーザー");
    }
  };

  const handleSendMessage = async (text: string) => {
    if (signalRService.current) {
      try {
        await signalRService.current.sendMessage(currentUser, text);
      } catch (error) {
        console.error("メッセージ送信エラー:", error);
        alert("メッセージの送信に失敗しました");
      }
    }
  };

  const handleLogin = () => {
    window.location.href = "/.auth/login/aad";
  };

  const handleLogout = () => {
    window.location.href = "/.auth/logout";
  };

  return (
    <div className="flex flex-col h-screen">
      {/* ヘッダー */}
      <header className="bg-gradient-to-r from-blue-600 to-purple-600 text-white p-4 shadow-lg">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <h1 className="text-2xl font-bold">💬 リアルタイムチャット</h1>
          <div className="flex items-center gap-4">
            <a
              href="/profile"
              className="px-4 py-2 bg-white/20 hover:bg-white/30 rounded-lg transition-colors"
            >
              プロフィール
            </a>
            <UserInfo
              username={currentUser}
              isAuthenticated={isAuthenticated}
              onLogin={handleLogin}
              onLogout={handleLogout}
            />
          </div>
        </div>
      </header>

      {/* メインコンテンツ */}
      <div className="flex-1 flex flex-col max-w-6xl w-full mx-auto">
        <ChatBox messages={messages} />
        <MessageInput onSend={handleSendMessage} disabled={!isConnected} />
      </div>

      {/* ステータスバー */}
      <div className="bg-gray-100 px-4 py-2 text-center text-sm text-gray-600">
        {isConnected ? "✅ 接続済み" : "⏳ 接続中..."}
      </div>
    </div>
  );
}
