const express = require("express");
const app = express();
const port = process.env.PORT || 3000;

app.use(express.json());

// GET エンドポイント
app.get("/api/hello", (req, res) => {
  res.json({ message: "Hello from API Apps!" });
});

// POST エンドポイント
app.post("/api/data", (req, res) => {
  const { name } = req.body;
  res.json({ message: `Received: ${name}`, timestamp: new Date() });
});

app.listen(port, () => {
  console.log(`API server running on port ${port}`);
});
