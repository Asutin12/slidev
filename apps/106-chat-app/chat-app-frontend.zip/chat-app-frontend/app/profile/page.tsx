// app/profile/page.tsx
"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

interface UserProfile {
  userId: string;
  userDetails: string;
  identityProvider: string;
  userRoles: string[];
  claims?: any[];
}

export default function ProfilePage() {
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const router = useRouter();

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const response = await fetch("/.auth/me");
        const payload = await response.json();
        const { clientPrincipal } = payload;

        if (!clientPrincipal) {
          // 未認証の場合はホームにリダイレクト
          router.push("/");
          return;
        }

        setProfile(clientPrincipal);
      } catch (error) {
        console.error("プロフィール取得エラー:", error);
        router.push("/");
      } finally {
        setLoading(false);
      }
    };

    fetchProfile();
  }, [router]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-xl">読み込み中...</div>
      </div>
    );
  }

  if (!profile) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-gradient-to-r from-blue-600 to-purple-600 text-white p-4 shadow-lg">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <h1 className="text-2xl font-bold">👤 プロフィール</h1>
          <button
            onClick={() => router.push("/")}
            className="px-4 py-2 bg-white/20 hover:bg-white/30 rounded-lg transition-colors"
          >
            チャットに戻る
          </button>
        </div>
      </header>

      <main className="max-w-4xl mx-auto p-6">
        <div className="bg-white rounded-lg shadow-md p-6 space-y-4">
          <div className="border-b pb-4">
            <h2 className="text-xl font-semibold text-gray-800 mb-2">
              ユーザー情報
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium text-gray-600">
                ユーザー名
              </label>
              <p className="text-lg text-gray-900">{profile.userDetails}</p>
            </div>

            <div>
              <label className="text-sm font-medium text-gray-600">
                ユーザー ID
              </label>
              <p className="text-sm text-gray-900 font-mono break-all">
                {profile.userId}
              </p>
            </div>

            <div>
              <label className="text-sm font-medium text-gray-600">
                認証プロバイダー
              </label>
              <p className="text-lg text-gray-900">
                {profile.identityProvider === "aad"
                  ? "Microsoft"
                  : profile.identityProvider}
              </p>
            </div>

            <div>
              <label className="text-sm font-medium text-gray-600">
                ロール
              </label>
              <div className="flex gap-2 flex-wrap mt-1">
                {profile.userRoles.map((role, index) => (
                  <span
                    key={index}
                    className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm"
                  >
                    {role}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {profile.claims && profile.claims.length > 0 && (
            <div className="mt-6">
              <label className="text-sm font-medium text-gray-600 mb-2 block">
                追加情報（Claims）
              </label>
              <div className="bg-gray-50 rounded p-4 overflow-x-auto">
                <pre className="text-xs">
                  {JSON.stringify(profile.claims, null, 2)}
                </pre>
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
