// app/page.tsx
"use client";
import { getAppInsights } from "@/lib/appInsights";

export default function Home() {
  const handleClick = () => {
    console.log("ボタンがクリックされました");
    const appInsights = getAppInsights();

    if (!appInsights) {
      console.error("❌ Application Insightsが初期化されていません");
      alert(
        "Application Insightsが設定されていません。環境変数を確認してください。"
      );
      return;
    }

    try {
      appInsights.trackEvent({
        name: "ButtonClicked",
        properties: { page: "home" },
      });
      console.log("✅ イベント送信成功: ButtonClicked");
      alert("イベントを送信しました！（コンソールを確認してください）");
    } catch (error) {
      console.error("❌ イベント送信エラー:", error);
    }
  };

  return (
    <main style={{ padding: "2rem", fontFamily: "sans-serif" }}>
      <h1>Hello, Azure App Service!</h1>
      <p>Application Insightsのテストページです</p>
      <button
        onClick={handleClick}
        style={{
          padding: "10px 20px",
          fontSize: "16px",
          cursor: "pointer",
          backgroundColor: "#0070f3",
          color: "white",
          border: "none",
          borderRadius: "5px",
        }}
      >
        Click me (tracked)
      </button>
      <div style={{ marginTop: "20px", fontSize: "14px", color: "#666" }}>
        <p>ブラウザのコンソールを開いて、ログを確認してください。</p>
      </div>
    </main>
  );
}
