// lib/appInsights.ts
import { ApplicationInsights } from "@microsoft/applicationinsights-web";

let appInsights: ApplicationInsights | null = null;

export function getAppInsights() {
  if (typeof window !== "undefined" && !appInsights) {
    const connectionString =
      process.env.NEXT_PUBLIC_APPINSIGHTS_CONNECTION_STRING;

    // デバッグ用: Connection Stringの状態を確認
    console.log("Application Insights初期化開始");
    console.log("Connection String存在:", !!connectionString);

    if (!connectionString) {
      console.error(
        "❌ Application Insights Connection Stringが設定されていません"
      );
      console.error(
        "環境変数 NEXT_PUBLIC_APPINSIGHTS_CONNECTION_STRING を設定してください"
      );
      return null;
    }

    try {
      appInsights = new ApplicationInsights({
        config: {
          connectionString: connectionString,
          enableAutoRouteTracking: true,
          enableDebug: true, // デバッグモードを有効化
          loggingLevelConsole: 2, // 詳細ログを出力 (0=OFF, 1=CRITICAL, 2=WARNING)
        },
      });
      appInsights.loadAppInsights();
      appInsights.trackPageView(); // 初回ページビュー
      console.log("✅ Application Insights初期化成功");
    } catch (error) {
      console.error("❌ Application Insights初期化エラー:", error);
      appInsights = null;
    }
  }
  return appInsights;
}
