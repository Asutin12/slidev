// app.js
const express = require("express");
const app = express();

// 環境変数から設定を読み込み
const port = process.env.PORT || process.env.WEBSITES_PORT || 3000;
const nodeEnv = process.env.NODE_ENV || "development";
const logLevel = process.env.LOG_LEVEL || "info";
const apiBaseUrl = process.env.API_BASE_URL || "http://localhost:8080";

app.get("/", (req, res) => {
  res.json({
    message: "Hello from Container!",
    environment: nodeEnv,
    logLevel: logLevel,
    apiBaseUrl: apiBaseUrl,
    hostname: require("os").hostname(),
    timestamp: new Date().toISOString(),
  });
});

app.get("/env", (req, res) => {
  // 設定情報を表示（機密情報は除外）
  res.json({
    NODE_ENV: process.env.NODE_ENV,
    LOG_LEVEL: process.env.LOG_LEVEL,
    API_BASE_URL: process.env.API_BASE_URL,
    // パスワードやAPIキーは含めない
  });
});

app.listen(port, "0.0.0.0", () => {
  console.log(`Server running on port ${port} (${nodeEnv} mode)`);
});
