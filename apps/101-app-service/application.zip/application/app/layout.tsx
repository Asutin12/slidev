// app/layout.tsx
"use client";
import { useEffect } from "react";
import { getAppInsights } from "@/lib/appInsights";

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  useEffect(() => {
    getAppInsights(); // 初期化
  }, []);

  return (
    <html lang="ja">
      <body>{children}</body>
    </html>
  );
}
