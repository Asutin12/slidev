// components/UserInfo.tsx
"use client";

interface UserInfoProps {
  username: string;
  isAuthenticated: boolean;
  onLogin: () => void;
  onLogout: () => void;
}

export default function UserInfo({
  username,
  isAuthenticated,
  onLogin,
  onLogout,
}: UserInfoProps) {
  return (
    <div className="flex items-center gap-4">
      <span className="font-medium text-white">
        {isAuthenticated ? username : "Anonymous"}
      </span>
      {isAuthenticated ? (
        <button
          onClick={onLogout}
          className="px-4 py-2 bg-white/20 hover:bg-white/30 text-white rounded-lg transition-colors"
        >
          ログアウト
        </button>
      ) : (
        <button
          onClick={onLogin}
          className="px-4 py-2 bg-white text-blue-600 hover:bg-gray-100 rounded-lg transition-colors font-medium"
        >
          ログイン
        </button>
      )}
    </div>
  );
}
