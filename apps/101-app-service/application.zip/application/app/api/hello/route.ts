// app/api/hello/route.ts
import { NextResponse } from "next/server";
const appInsights = require("applicationinsights");

// サーバー起動時に一度だけ初期化
if (!appInsights.defaultClient) {
  appInsights
    .setup(process.env.APPLICATIONINSIGHTS_CONNECTION_STRING)
    .setAutoDependencyCorrelation(true)
    .setAutoCollectRequests(true)
    .start();
}

export async function GET() {
  const client = appInsights.defaultClient;

  // カスタムイベント
  client.trackEvent({
    name: "APICallReceived",
    properties: { endpoint: "/api/hello" },
  });

  return NextResponse.json({ message: "Hello from API!" });
}
