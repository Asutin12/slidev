import azure.functions as func
import logging
from PIL import Image
from io import BytesIO
import json
from datetime import datetime

app = func.FunctionApp()

@app.function_name(name="HttpTriggerDemo")
@app.route(route="HttpTriggerDemo", methods=["GET", "POST"], auth_level=func.AuthLevel.ANONYMOUS)
def http_trigger_demo(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('HTTP trigger function processed a request.')

    name = req.params.get('name')
    if not name:
        try:
            req_body = req.get_json()
            name = req_body.get('name')
        except ValueError:
            name = req.get_body().decode('utf-8') if req.get_body() else None

    if not name:
        name = "World"

    response_data = {
        "message": f"Hello, {name}!",
        "timestamp": datetime.utcnow().isoformat() + "Z"
    }

    return func.HttpResponse(
        json.dumps(response_data),
        status_code=200,
        mimetype="application/json"
    )


@app.function_name(name="TimerTriggerDemo")
@app.schedule(
    schedule="0 */5 * * * *",  # ← 5分おきに実行
    arg_name="myTimer",
    run_on_startup=False,
    use_monitor=False
)
def timer_trigger_demo(myTimer: func.TimerRequest) -> None:
    logging.info('Timer trigger function executed at: %s', datetime.utcnow().isoformat())

    # 定期実行したい処理を書く
    logging.info('Periodic task executed')

    if myTimer.past_due:
        logging.info('The timer is past due!')


@app.function_name(name="BlobTriggerDemo")
@app.blob_trigger(
    arg_name="inputblob",
    path="images/{name}",
    connection="AzureWebJobsStorage"
)
@app.blob_output(
    arg_name="outputblob",
    path="thumbnails/{name}",
    connection="AzureWebJobsStorage"
)
def ThumbnailGenerator(inputblob: func.InputStream, outputblob: func.Out[bytes]):
    logging.info(f'Blob trigger processing: {inputblob.name}')

    try:
        # 画像を読み込み
        image = Image.open(inputblob)

        # サムネイル生成（幅200pxに縮小、アスペクト比維持）
        image.thumbnail((200, 200), Image.Resampling.LANCZOS)

        # BytesIOに保存
        output = BytesIO()
        image.save(output, format=image.format or 'JPEG')

        # Output Bindingに設定
        outputblob.set(output.getvalue())

        logging.info('Thumbnail generated successfully')
    except Exception as e:
        logging.error(f'Error generating thumbnail: {e}')
        raise


@app.function_name(name="QueueTriggerDemo")
@app.queue_trigger(
    arg_name="msg",
    queue_name="tasks",
    connection="AzureWebJobsStorage"
)
def queue_trigger_demo(msg: func.QueueMessage):
    try:
        # メッセージの取得
        message_body = msg.get_body().decode('utf-8')
        logging.info('Queue trigger function received message: %s', message_body)

        # JSON 解析
        try:
            task = json.loads(message_body)
        except json.JSONDecodeError as e:
            logging.error('Failed to decode JSON: %s', e)
            # JSON 解析失敗は Poison に入れないよう処理を終了
            return

        logging.info('Task ID: %s', task.get('id'))
        logging.info('Task Type: %s', task.get('type'))
        logging.info('Task Data: %s', task.get('data'))

        # ここで非同期タスク処理を実装
        # 例: メール送信、データベース更新など
        # 必要に応じて try/except で個別に保護

    except Exception as error:
        # 全体例外はログに残すだけで Poison に入れない
        logging.error('Unexpected error processing queue message: %s', error)


@app.function_name(name="EventGridTriggerDemo")
@app.event_grid_trigger(arg_name="event")
def event_grid_trigger_demo(event: func.EventGridEvent):
    logging.info('Event Grid trigger function processed an event')
    logging.info('Event Type: %s', event.event_type)
    logging.info('Event Subject: %s', event.subject)
    logging.info('Event Data: %s', json.dumps(event.get_json()))
    logging.info('Event Time: %s', event.event_time)

    # イベントタイプに応じた処理
    event_data = event.get_json()

    if event.event_type == "OrderCreated":
        logging.info('Processing new order: %s', event_data.get('orderId'))
        # 注文処理ロジック
    elif event.event_type == "OrderCancelled":
        logging.info('Processing order cancellation: %s', event_data.get('orderId'))
        # キャンセル処理ロジック
    elif event.event_type == "OrderShipped":
        logging.info('Processing order shipment: %s', event_data.get('orderId'))
        # 発送処理ロジック
    else:
        logging.info('Unknown event type')


@app.function_name(name="EventGridNotificationDemo")
@app.event_grid_trigger(arg_name="event")
def event_grid_notification_demo(event: func.EventGridEvent):
    logging.info('Notification function processed an event')

    # 通知ロジック
    if event.event_type == "OrderCreated":
        logging.info('Sending confirmation email to customer')
        # メール送信処理
    elif event.event_type == "OrderShipped":
        logging.info('Sending shipment notification')
        # 発送通知送信処理
